package ID27335.Q2;

import java.time.LocalDate;

class Pilot extends Flight {
    public Pilot(int id, LocalDate c, LocalDate u) {
        super(id, c, u, "F", "D", "Dst", 1.0, null);
    }
}
