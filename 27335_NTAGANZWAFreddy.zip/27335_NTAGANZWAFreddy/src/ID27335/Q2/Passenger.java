package ID27335.Q2;

import java.time.LocalDate;

class Passenger extends CabinCrew {
    private String passengerName;
    private int age;
    private String gender;
    private String contact;

    public Passenger(int id, LocalDate c, LocalDate u, String passengerName, int age, String gender, String contact) {
        super(id, c, u);
        if (age <= 0) throw new IllegalArgumentException("age>0");
        this.passengerName = passengerName;
        this.age = age;
        this.gender = gender;
        this.contact = contact;
    }

    public String getName() {
        return passengerName;
    }

    public int getAge() {
        return age;
    }
}
