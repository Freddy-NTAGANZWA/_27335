package ID27335.Q2;

import java.time.LocalDate;
import java.util.Scanner;



public class FlightBookingSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("27335 Enter entity id (>0):");
            int id = Integer.parseInt(sc.nextLine());

            System.out.println("27335 Enter airport name:");
            String aname = sc.nextLine();
            System.out.println("27335 Enter airport code (3 uppercase letters):");
            String aCode = sc.nextLine();
            Airport airport = new Airport(id, LocalDate.now(), LocalDate.now(), aname, aCode, "Some Location");

            System.out.println("27335 Enter airline name:");
            String airlineName = sc.nextLine();
            System.out.println("27335 Enter airline code (2-4 letters):");
            String airlineCode = sc.nextLine();
            System.out.println("27335 Enter airline contact email:");
            String email = sc.nextLine();
            Airline airline = new Airline(id+1, LocalDate.now(), LocalDate.now(), airlineName, airlineCode, email);

            System.out.println("27335 Enter flight number:");
            String flightNo = sc.nextLine();
            System.out.println("27335 Enter departure:");
            String depart = sc.nextLine();
            System.out.println("27335 Enter destination:");
            String dest = sc.nextLine();
            System.out.println("27335 Enter base fare (>0):");
            double baseFare = Double.parseDouble(sc.nextLine());
            Flight flight = new Flight(id+2, LocalDate.now(), LocalDate.now(), flightNo, depart, dest, baseFare, airline);

            System.out.println("27335 Enter passenger name:");
            String pname = sc.nextLine();
            System.out.println("27335 Enter age (>0):");
            int age = Integer.parseInt(sc.nextLine());
            System.out.println("27335 Enter gender (M/F):");
            String gender = sc.nextLine();
            System.out.println("27335 Enter contact:");
            String contact = sc.nextLine();
            Passenger p = new Passenger(id+3, LocalDate.now(), LocalDate.now(), pname, age, gender, contact);

            System.out.println("27335 Enter travel class (Economy/Business/First):");
            String travelClass = sc.nextLine();
            System.out.println("27335 Enter seat number:");
            String seat = sc.nextLine();
            Booking booking = new Booking(id+4, LocalDate.now(), LocalDate.now(), LocalDate.now(), seat, travelClass, p, flight);

            Ticket ticket = new Ticket(id+5, LocalDate.now(), LocalDate.now(), booking);
            ticket.issueTicket();

        } catch (Exception e) {
            System.out.println("27335 ERROR: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}

