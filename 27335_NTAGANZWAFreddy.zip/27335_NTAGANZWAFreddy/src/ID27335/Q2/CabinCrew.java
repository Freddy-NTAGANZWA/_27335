package ID27335.Q2;

import java.time.LocalDate;

class CabinCrew extends Pilot {
    public CabinCrew(int id, LocalDate c, LocalDate u) {
        super(id, c, u);
    }
}
