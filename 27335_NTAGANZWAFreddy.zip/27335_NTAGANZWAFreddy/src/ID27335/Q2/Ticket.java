package ID27335.Q2;

import java.time.LocalDate;

final class Ticket extends Payment {
    private Booking booking;

    public Ticket(int id, LocalDate c, LocalDate u, Booking booking) {
        super(id, c, u);
        this.booking = booking;
    }

    public void issueTicket() {
        double fare = booking.calculateFare();
        System.out.println("27335 --- TICKET ---");
        System.out.println("27335 Passenger: " + booking.passenger.getName());
        System.out.println("27335 Fare: " + fare);
        System.out.println("27335 Ticket issued number: TKT" + System.currentTimeMillis());
    }
}
