package ID27335.Q2;

import java.time.LocalDate;

class Airline extends Airport {
    private String airlineName;
    private String airlineCode;
    private String contactEmail;

    public Airline(int id, LocalDate c, LocalDate u, String airlineName, String airlineCode, String contactEmail) {
        super(id, c, u, "tmp", "AAA", "loc");
        if (airlineCode == null || !airlineCode.matches("[A-Za-z]{2,4}"))
            throw new IllegalArgumentException("code 2-4 letters");
        if (contactEmail == null || !contactEmail.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"))
            throw new IllegalArgumentException("invalid email");
        this.airlineName = airlineName;
        this.airlineCode = airlineCode;
        this.contactEmail = contactEmail;
    }
}
