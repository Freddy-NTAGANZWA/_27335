package ID27335.Q2;

import java.time.LocalDate;

class Payment extends Booking {
    public Payment(int id, LocalDate c, LocalDate u) {
        super(id, c, u, LocalDate.now(), "1A", "Economy", null, null);
    }
}
