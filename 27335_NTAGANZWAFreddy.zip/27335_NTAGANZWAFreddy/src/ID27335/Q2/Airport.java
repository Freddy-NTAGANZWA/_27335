package ID27335.Q2;

import java.time.LocalDate;

class Airport extends Entity {
    private String airportName;
    private String code;
    private String location;

    public Airport(int id, LocalDate c, LocalDate u, String airportName, String code, String location) {
        super(id, c, u);
        if (code == null || !code.matches("[A-Z]{3}")) throw new IllegalArgumentException("code=3 uppercase letters");
        this.airportName = airportName;
        this.code = code;
        this.location = location;
    }
}
