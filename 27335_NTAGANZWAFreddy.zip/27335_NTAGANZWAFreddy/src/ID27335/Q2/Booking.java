package ID27335.Q2;

import java.time.LocalDate;

class Booking extends Passenger {
    private LocalDate bookingDate;
    private String seatNumber;
    private String travelClass;
    Passenger passenger;
    private Flight flight;

    public Booking(int id, LocalDate c, LocalDate u, LocalDate bookingDate, String seatNumber, String travelClass, Passenger passenger, Flight flight) {
        super(id, c, u, "tmp", 1, "M", "c");
        if (!("Economy".equalsIgnoreCase(travelClass) || "Business".equalsIgnoreCase(travelClass) || "First".equalsIgnoreCase(travelClass)))
            throw new IllegalArgumentException("class must be Economy/Business/First");
        this.bookingDate = bookingDate;
        this.seatNumber = seatNumber;
        this.travelClass = travelClass;
        this.passenger = passenger;
        this.flight = flight;
    }

    public double calculateFare() {
        double base = flight.getBaseFare();
        double tax = base * 0.1;
        double discount = "Economy".equalsIgnoreCase(travelClass) ? 0 : ("Business".equalsIgnoreCase(travelClass) ? base * 0.05 : base * 0.1);
        return base + tax - discount;
    }
}
