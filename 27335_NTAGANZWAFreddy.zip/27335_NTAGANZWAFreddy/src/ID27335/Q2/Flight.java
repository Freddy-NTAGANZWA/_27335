package ID27335.Q2;

import java.time.LocalDate;

class Flight extends Airline {
    private String flightNumber;
    private String departure;
    private String destination;
    private double baseFare;
    private Airline airline;

    public Flight(int id, LocalDate c, LocalDate u, String flightNumber, String departure, String destination, double baseFare, Airline airline) {
        super(id, c, u, "tmp", "TP", "tmp@x.com");
        if (baseFare <= 0) throw new IllegalArgumentException("fare>0");
        this.flightNumber = flightNumber;
        this.departure = departure;
        this.destination = destination;
        this.baseFare = baseFare;
        this.airline = airline;
    }

    public double getBaseFare() {
        return baseFare;
    }
}
