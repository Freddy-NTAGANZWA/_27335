package ID27335.Q3;

import java.time.LocalDate;

class TaxDeclaration extends Employee {
    public TaxDeclaration(int id, LocalDate c, LocalDate u, String month, double income) {
        super(id, c, u, "emp", income, "0123456789");
        if (income < 0) throw new IllegalArgumentException("income>=0");
    }
}
