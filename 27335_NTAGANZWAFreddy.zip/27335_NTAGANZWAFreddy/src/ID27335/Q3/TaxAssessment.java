package ID27335.Q3;

import java.time.LocalDate;

class TaxAssessment extends TaxDeclaration {
    private LocalDate assessmentDate;
    private double assessedTax;

    public TaxAssessment(int id, LocalDate assessmentDate, LocalDate u, double assessedTax) {
        super(id, assessmentDate, u, "M", assessedTax);
        if (assessedTax < 0) throw new IllegalArgumentException("tax>=0");
        this.assessmentDate = assessmentDate;
        this.assessedTax = assessedTax;
    }

    public double getAssessedTax() {
        return assessedTax;
    }
}
