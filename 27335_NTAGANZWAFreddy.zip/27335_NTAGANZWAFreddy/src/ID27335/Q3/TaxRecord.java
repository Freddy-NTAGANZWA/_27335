package ID27335.Q3;

import java.time.LocalDate;

final class TaxRecord extends Payment {
    private String receiptNo;
    private double totalTax;

    public TaxRecord(int id, LocalDate c, LocalDate u, String receiptNo, double totalTax) {
        super(id, c, u, c, totalTax);
        this.receiptNo = receiptNo;
        this.totalTax = totalTax;
    }

    public void computeTax(Employee emp, TaxCategory tc) {
        double rate = tc.getRate();
        double salary = emp.getSalary();
        double total = (salary * rate);
        System.out.println("27335 --- TAX RECORD ---");
        System.out.println("27335 Receipt: " + receiptNo);
        System.out.println("27335 Salary: " + salary);
        System.out.println("27335 Rate: " + rate);
        System.out.println("27335 Total tax payable: " + total);
    }
}
