package ID27335.Q3;

import java.time.LocalDate;

class TaxCategory extends TaxAuthority {
    private String categoryName;
    private double rate;
    private String code;

    public TaxCategory(int id, LocalDate c, LocalDate u, String categoryName, double rate, String code) {
        super(id, c, u, "auth", "r", "e");
        if (rate <= 0) throw new IllegalArgumentException("rate>0");
        if (code == null || code.length() < 3) throw new IllegalArgumentException("code >=3 chars");
        this.categoryName = categoryName;
        this.rate = rate;
        this.code = code;
    }

    public double getRate() {
        return rate;
    }
}
