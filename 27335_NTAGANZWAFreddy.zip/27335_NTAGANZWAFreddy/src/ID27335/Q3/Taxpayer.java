package ID27335.Q3;

import java.time.LocalDate;

class Taxpayer extends TaxCategory {
    private String tin;
    private String taxpayerName;
    private String address;

    public Taxpayer(int id, LocalDate c, LocalDate u, String tin, String taxpayerName, String address) {
        super(id, c, u, "cat", 0.01, "CDE");
        if (tin == null || !tin.matches("\\d{9}")) throw new IllegalArgumentException("TIN 9 digits");
        this.tin = tin;
        this.taxpayerName = taxpayerName;
        this.address = address;
    }

    public String getTin() {
        return tin;
    }
}
