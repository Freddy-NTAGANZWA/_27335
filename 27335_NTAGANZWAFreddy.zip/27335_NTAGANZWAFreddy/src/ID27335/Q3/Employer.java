package ID27335.Q3;

import java.time.LocalDate;

class Employer extends Taxpayer {
    public Employer(int id, LocalDate c, LocalDate u, String employerName, String employerTIN, String contact) {
        super(id, c, u, employerTIN, employerName, "addr");
        if (!employerTIN.matches("\\d{9}")) throw new IllegalArgumentException("valid TIN");
    }
}
