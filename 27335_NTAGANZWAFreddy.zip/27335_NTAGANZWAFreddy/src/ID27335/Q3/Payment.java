package ID27335.Q3;

import java.time.LocalDate;

class Payment extends TaxAssessment {
    public Payment(int id, LocalDate c, LocalDate u, LocalDate paymentDate, double amount) {
        super(id, paymentDate, u, amount);
        if (amount <= 0) throw new IllegalArgumentException("amount>0");
    }
}
