package ID27335.Q3;

import java.time.LocalDate;
import java.util.Scanner;



public class TaxAdministrationSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("27335 Enter taxpayer id (>0):");
            int id = Integer.parseInt(sc.nextLine());
            System.out.println("27335 Enter taxpayer name:");
            String tname = sc.nextLine();
            System.out.println("27335 Enter TIN (9 digits):");
            String tin = sc.nextLine();
            if (!tin.matches("\\d{9}")) throw new RuntimeException("TIN must be 9 digits");

            System.out.println("27335 Enter salary (>0):");
            double salary = Double.parseDouble(sc.nextLine());
            System.out.println("27335 Enter tax category code (>=3 chars):");
            String code = sc.nextLine();
            System.out.println("27335 Enter tax rate (>0) (as decimal e.g., 0.15):");
            double rate = Double.parseDouble(sc.nextLine());

            Taxpayer tp = new Taxpayer(id, LocalDate.now(), LocalDate.now(), tin, tname, "addr");
            TaxCategory tc = new TaxCategory(id+1, LocalDate.now(), LocalDate.now(), "Income", rate, code);
            Employee emp = new Employee(id+2, LocalDate.now(), LocalDate.now(), "Employee", salary, tin);
            TaxAssessment assessment = new TaxAssessment(id+3, LocalDate.now(), LocalDate.now(), salary*rate);

            TaxRecord record = new TaxRecord(id+4, LocalDate.now(), LocalDate.now(), "RCPT"+id, assessment.getAssessedTax());
            record.computeTax(emp, tc);

        } catch (Exception e) {
            System.out.println("27335 ERROR: " + e.getMessage());
        } finally { sc.close(); }
    }
}

