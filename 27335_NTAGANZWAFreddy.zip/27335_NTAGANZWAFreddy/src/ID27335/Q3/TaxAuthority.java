package ID27335.Q3;

import java.time.LocalDate;

class TaxAuthority extends Entity {
    public TaxAuthority(int id, LocalDate c, LocalDate u, String name, String region, String email) {
        super(id, c, u);
    }
}
