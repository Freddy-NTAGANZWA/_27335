package ID27335.Q3;

import java.time.LocalDate;

class Employee extends Employer {
    private String employeeName;
    private double salary;
    private String employeeTIN;

    public Employee(int id, LocalDate c, LocalDate u, String employeeName, double salary, String employeeTIN) {
        super(id, c, u, "emp", employeeTIN, "contact");
        if (salary <= 0) throw new IllegalArgumentException("salary>0");
        if (!employeeTIN.matches("\\d{9}")) throw new IllegalArgumentException("TIN 9 digits");
        this.employeeName = employeeName;
        this.salary = salary;
        this.employeeTIN = employeeTIN;
    }

    public double getSalary() {
        return salary;
    }
}
