package ID27335.Q1;

import java.time.LocalDate;


class Warehouse extends Entity {
    private String warehouseName;
    private String location;
    private String contactNumber;

    public Warehouse(int id, LocalDate c, LocalDate u, String warehouseName, String location, String contactNumber) {
        super(id,c,u);
        if (contactNumber == null || !contactNumber.matches("\\d{10}"))
            throw new IllegalArgumentException("phone must be 10 digits");
        this.warehouseName = warehouseName;
        this.location = location;
        this.contactNumber = contactNumber;
    }
    public String getWarehouseName() { return warehouseName; }
}

