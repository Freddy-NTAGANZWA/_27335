package ID27335.Q1;

import java.time.LocalDate;

class Purchase extends StockItem {
    private LocalDate purchaseDate;
    private int purchasedQuantity;
    private String supplierName;

    public Purchase(int id, LocalDate purchaseDate, LocalDate updatedDate, int purchasedQuantity, String supplierName) {
        super(id, updatedDate, updatedDate, new Product(0, updatedDate, updatedDate, "tmp", 1.0, 0, null, null), 0, 0);
        if (purchaseDate == null) throw new IllegalArgumentException("date null");
        if (purchasedQuantity <= 0) throw new IllegalArgumentException("quantity > 0");
        this.purchaseDate = purchaseDate;
        this.purchasedQuantity = purchasedQuantity;
        this.supplierName = supplierName;
    }

    public int getPurchasedQuantity() {
        return purchasedQuantity;
    }
}
