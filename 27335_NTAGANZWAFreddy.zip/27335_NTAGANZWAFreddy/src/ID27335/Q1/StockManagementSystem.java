package ID27335.Q1;

import java.time.LocalDate;
import java.util.Scanner;

public class StockManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("27335 Enter warehouse id (>0):");
            int id = Integer.parseInt(sc.nextLine());
            System.out.println("27335 Enter warehouse name:");
            String wname = sc.nextLine();
            System.out.println("27335 Enter location:");
            String loc = sc.nextLine();
            System.out.println("27335 Enter 10-digit contact number:");
            String phone = sc.nextLine();

            Warehouse wh = new Warehouse(id, LocalDate.now(), LocalDate.now(), wname, loc, phone);

            System.out.println("27335 Enter category name:");
            String cname = sc.nextLine();
            System.out.println("27335 Enter category code (>=3 alphanumeric):");
            String ccode = sc.nextLine();
            Category cat = new Category(id+1, LocalDate.now(), LocalDate.now(), cname, ccode);

            System.out.println("27335 Enter supplier name:");
            String sname = sc.nextLine();
            System.out.println("27335  Enter supplier email:");
            String semail = sc.nextLine();
            System.out.println("27335 Enter supplier 10-digit phone:");
            String sphone = sc.nextLine();
            Supplier sup = new Supplier(id+2, LocalDate.now(), LocalDate.now(), sname, semail, sphone);

            System.out.println("27335 Enter product name:");
            String pname = sc.nextLine();
            System.out.println("27335 Enter unit price (>0):");
            double price = Double.parseDouble(sc.nextLine());
            System.out.println("27335 Enter stock limit (>=0):");
            int stockLimit = Integer.parseInt(sc.nextLine());
            Product prod = new Product(id+3, LocalDate.now(), LocalDate.now(), pname, price, stockLimit, cat, sup);

            System.out.println("27335 Enter initial quantity available (>=0):");
            int qty = Integer.parseInt(sc.nextLine());
            System.out.println("27335 Enter reorder level (>=0):");
            int reorder = Integer.parseInt(sc.nextLine());
            StockItem item = new StockItem(id+4, LocalDate.now(), LocalDate.now(), prod, qty, reorder);


            System.out.println("27335 Enter purchase date (YYYY-MM-DD):");
            String pdate = sc.nextLine();
            System.out.println("27335 Enter purchased quantity (>0):");
            int pQty = Integer.parseInt(sc.nextLine());
            Purchase purchase = new Purchase(id+5, LocalDate.parse(pdate), LocalDate.now(), pQty, sup.getSupplierName());


            System.out.println("27335 Enter sale date (YYYY-MM-DD):");
            String sdate = sc.nextLine();
            System.out.println("27335 Enter sold quantity (>0):");
            int sQty = Integer.parseInt(sc.nextLine());
            System.out.println("27335 Enter customer name:");
            String cust = sc.nextLine();
            Sale sale = new Sale(id+6, LocalDate.parse(sdate), LocalDate.now(), sQty, cust);


            Inventory inv = new Inventory(id+7, LocalDate.now(), LocalDate.now());
            inv.addStockItem(item);
            inv.addPurchase(purchase);
            inv.addSale(sale);

            StockReport report = new StockReport(id+8, LocalDate.now(), LocalDate.now(), LocalDate.now(), "Monthly summary");
            report.generateReport(inv);

        } catch (Exception e) {
            System.out.println("27335 ERROR: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}
