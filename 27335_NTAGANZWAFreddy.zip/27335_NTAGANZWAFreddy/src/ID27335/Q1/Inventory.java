package ID27335.Q1;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


class Inventory extends Entity {
    private List<StockItem> items = new ArrayList<>();
    private List<Purchase> purchases = new ArrayList<>();
    private List<Sale> sales = new ArrayList<>();

    public Inventory(int id, LocalDate c, LocalDate u) {
        super(id, c, u);
    }

    public void addStockItem(StockItem item) {
        items.add(item);
    }

    public void addPurchase(Purchase p) {
        purchases.add(p);
        if (!items.isEmpty()) items.get(0).addQuantity(p.getPurchasedQuantity());
    }

    public void addSale(Sale s) {
        sales.add(s);
        if (!items.isEmpty()) items.get(0).reduceQuantity(s.getSoldQuantity());
    }

    public int totalItems() {
        int total = 0;
        for (StockItem si : items) total += si.getQuantityAvailable();
        return total;
    }

    public double stockValue() {
        double v = 0;
        for (StockItem si : items) v += si.getQuantityAvailable() * si.getUnitPrice();
        return v;
    }

    public List<Sale> getSales() {
        return sales;
    }
}
