package ID27335.Q1;

import java.time.LocalDate;


final class StockReport extends Inventory {
    private LocalDate reportDate;
    private String remarks;

    public StockReport(int id, LocalDate c, LocalDate u, LocalDate reportDate, String remarks) {
        super(id, c, u);
        this.reportDate = reportDate;
        this.remarks = remarks;
    }

    public void generateReport(Inventory inv) {
        System.out.println("27335 --- STOCK REPORT ---");
        System.out.println("27335 Report date: " + reportDate);
        System.out.println("27335 Total items in inventory: " + inv.totalItems());
        System.out.println("27335 Total stock value: " + inv.stockValue());
        int totalSold = 0;
        for (Sale s : inv.getSales()) totalSold += s.getSoldQuantity();
        System.out.println("27335 Total sold: " + totalSold);
        System.out.println("27335 Remarks: " + remarks);
    }
}
