package ID27335.Q1;

import java.time.LocalDate;


class Product extends Supplier {
    private String productName;
    private double unitPrice;
    private int stockLimit;
    private Category category;
    private Supplier supplier;

    public Product(int id, LocalDate c, LocalDate u, String productName, double unitPrice, int stockLimit, Category category, Supplier supplier) {
        super(id, c, u, "sup", "sup@example.com", "0123456789");
        if (unitPrice <= 0) throw new IllegalArgumentException("unitPrice must be > 0");
        if (stockLimit < 0) throw new IllegalArgumentException("stockLimit must be >= 0");
        this.productName = productName;
        this.unitPrice = unitPrice;
        this.stockLimit = stockLimit;
        this.category = category;
        this.supplier = supplier;
    }

    public String getProductName() {
        return productName;
    }

    public double getUnitPrice() {
        return unitPrice;
    }
}
