package ID27335.Q1;

import java.time.LocalDate;


class Supplier extends Category {
    private String supplierName;
    private String supplierEmail;
    private String supplierPhone;

    public Supplier(int id, LocalDate c, LocalDate u, String supplierName, String supplierEmail, String supplierPhone) {
        super(id, c, u, "cat", "CAT");
        if (supplierEmail == null || !supplierEmail.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"))
            throw new IllegalArgumentException("invalid email");
        if (supplierPhone == null || !supplierPhone.matches("\\d{10}"))
            throw new IllegalArgumentException("phone must be 10 digits");
        this.supplierName = supplierName;
        this.supplierEmail = supplierEmail;
        this.supplierPhone = supplierPhone;
    }

    public String getSupplierName() {
        return supplierName;
    }
}
