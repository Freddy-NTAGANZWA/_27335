package ID27335.Q1;

import java.time.LocalDate;

class Category extends Warehouse {
    private String categoryName;
    private String categoryCode;

    public Category(int id, LocalDate c, LocalDate u, String categoryName, String categoryCode) {
        super(id, c, u, "tmp", "tmp", "0000000000");
        if (categoryCode == null || categoryCode.length() < 3 || !categoryCode.matches("[A-Za-z0-9]+"))
            throw new IllegalArgumentException("code must be alphanumeric and >=3 chars");
        this.categoryName = categoryName;
        this.categoryCode = categoryCode;
    }

    public String getCategoryName() {
        return categoryName;
    }
}
