package ID27335.Q1;

import java.time.LocalDate;


class Sale extends Purchase {
    private LocalDate saleDate;
    private int soldQuantity;
    private String customerName;

    public Sale(int id, LocalDate saleDate, LocalDate updatedDate, int soldQuantity, String customerName) {
        super(id, saleDate, updatedDate, 1, "supplier");
        if (soldQuantity <= 0) throw new IllegalArgumentException("soldQuantity > 0");
        this.saleDate = saleDate;
        this.soldQuantity = soldQuantity;
        this.customerName = customerName;
    }

    public int getSoldQuantity() {
        return soldQuantity;
    }
}
