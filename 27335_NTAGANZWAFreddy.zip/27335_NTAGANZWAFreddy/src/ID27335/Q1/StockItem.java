package ID27335.Q1;

import java.time.LocalDate;

class StockItem extends Product {
    private int quantityAvailable;
    private int reorderLevel;

    public StockItem(int id, LocalDate c, LocalDate u, Product product, int quantityAvailable, int reorderLevel) {
        super(id, c, u, product.getProductName(), product.getUnitPrice(), 0, null, null);
        if (quantityAvailable < 0 || reorderLevel < 0) throw new IllegalArgumentException("values >=0");
        this.quantityAvailable = quantityAvailable;
        this.reorderLevel = reorderLevel;
    }

    public int getQuantityAvailable() {
        return quantityAvailable;
    }

    public void reduceQuantity(int q) {
        this.quantityAvailable -= q;
    }

    public void addQuantity(int q) {
        this.quantityAvailable += q;
    }
}
