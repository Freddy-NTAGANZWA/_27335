package ID27335.Q6;

import java.time.LocalDate;

class SalaryStructure extends PayrollPeriod {
    private final double basicPay;
    private final double transportAllowance;
    private final double housingAllowance;

    public SalaryStructure(int id, LocalDate c, LocalDate u, double basicPay, double transportAllowance, double housingAllowance) {
        super(id, c, u, 1, 2000, LocalDate.now(), LocalDate.now());
        if (basicPay < 0 || transportAllowance < 0 || housingAllowance < 0) throw new IllegalArgumentException(">=0");
        this.basicPay = basicPay;
        this.transportAllowance = transportAllowance;
        this.housingAllowance = housingAllowance;
    }

    public double getBasicPay() {
        return basicPay;
    }

    public double totalAllowances() {
        return transportAllowance + housingAllowance;
    }
}
