package ID27335.Q6;

import java.time.LocalDate;

class Organization extends Entity {
    public Organization(int id, LocalDate c, LocalDate u, String orgName, String orgCode, String rssbNumber, String contactEmail) {
        super(id, c, u);
        if (rssbNumber == null || rssbNumber.length() != 8) throw new IllegalArgumentException("rssbNumber=8 digits");
    }
}
