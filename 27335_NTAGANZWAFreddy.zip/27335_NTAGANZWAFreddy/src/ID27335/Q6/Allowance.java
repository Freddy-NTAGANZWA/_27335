package ID27335.Q6;

import java.time.LocalDate;

class Allowance extends Deduction {
    private double overtimeHours;
    private double overtimeRate;
    private double bonus;

    public Allowance(int id, LocalDate c, LocalDate u, double overtimeHours, double overtimeRate, double bonus) {
        super(id, c, u, 0, 0, 0);
        if (overtimeHours < 0 || overtimeRate < 0 || bonus < 0) throw new IllegalArgumentException(">=0");
        this.overtimeHours = overtimeHours;
        this.overtimeRate = overtimeRate;
        this.bonus = bonus;
    }

    public double totalAllowanceValue() {
        return overtimeHours * overtimeRate + bonus;
    }
}
