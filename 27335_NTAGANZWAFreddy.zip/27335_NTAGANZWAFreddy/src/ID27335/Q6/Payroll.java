package ID27335.Q6;

import java.time.LocalDate;

class Payroll extends Allowance {
    private double grossSalary;
    private double totalDeductions;
    private double netSalary;
    private SalaryStructure salaryStructure;
    private Allowance allowance;
    private Deduction deduction;

    public Payroll(int id, LocalDate c, LocalDate u, SalaryStructure salaryStructure, Allowance allowance, Deduction deduction) {
        super(id, c, u, 0, 0, 0);
        this.salaryStructure = salaryStructure;
        this.allowance = allowance;
        this.deduction = deduction;
        compute();
    }

    private void compute() {
        grossSalary = salaryStructure.getBasicPay() + allowance.totalAllowanceValue();
        totalDeductions = deduction.totalDeductions();
        netSalary = grossSalary - totalDeductions;
    }

    public double getGross() {
        return grossSalary;
    }

    public double getTotalDeductions() {
        return totalDeductions;
    }

    public double getNet() {
        return netSalary;
    }
}
