package ID27335.Q6;

import java.time.LocalDate;

class PayrollPeriod extends Employee {
    private int month;
    private int year;
    private LocalDate startDate;
    private LocalDate endDate;

    public PayrollPeriod(int id, LocalDate c, LocalDate u, int month, int year, LocalDate startDate, LocalDate endDate) {
        super(id, c, u, 1000, "n", "p", 1.0, false);
        if (month < 1 || month > 12) throw new IllegalArgumentException("month 1-12");
        if (year < 2000) throw new IllegalArgumentException("year>=2000");
        this.month = month;
        this.year = year;
        this.startDate = startDate;
        this.endDate = endDate;
    }
}
