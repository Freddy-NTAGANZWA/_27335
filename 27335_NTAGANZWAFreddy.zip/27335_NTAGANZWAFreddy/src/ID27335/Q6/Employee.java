package ID27335.Q6;

import java.time.LocalDate;

class Employee extends Department {
    private int employeeID;
    private String fullName;
    private String position;
    private double baseSalary;
    private boolean rssbRegistered;

    public Employee(int id, LocalDate c, LocalDate u, int employeeID, String fullName, String position, double baseSalary, boolean rssbRegistered) {
        super(id, c, u, "dept", "D", "Manager");
        if (employeeID < 1000) throw new IllegalArgumentException("employeeID>=1000");
        if (baseSalary <= 0) throw new IllegalArgumentException("baseSalary>0");
        this.employeeID = employeeID;
        this.fullName = fullName;
        this.position = position;
        this.baseSalary = baseSalary;
        this.rssbRegistered = rssbRegistered;
    }

    public int getEmployeeID() {
        return employeeID;
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    public String getFullName() {
        return fullName;
    }
}
