package ID27335.Q6;

import java.time.LocalDate;
import java.util.Scanner;


public class PayrollManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("27335 Enter employee ID (>=1000):");
            int empId = Integer.parseInt(sc.nextLine());
            System.out.println("27335 Enter full name:");
            String name = sc.nextLine();
            System.out.println("27335 Enter position:");
            String pos = sc.nextLine();
            System.out.println("27335 Enter base salary (>0):");
            double base = Double.parseDouble(sc.nextLine());
            System.out.println("27335 Is employee RSSB registered? (true/false):");
            boolean rssbReg = Boolean.parseBoolean(sc.nextLine());

            Employee emp = new Employee(empId, LocalDate.now(), LocalDate.now(), empId, name, pos, base, rssbReg);

            System.out.println("27335 Enter month (1-12):");
            int month = Integer.parseInt(sc.nextLine());
            System.out.println("27335 Enter year (>=2000):");
            int year = Integer.parseInt(sc.nextLine());
            PayrollPeriod period = new PayrollPeriod(empId+1, LocalDate.now(), LocalDate.now(), month, year, LocalDate.now().minusDays(30), LocalDate.now());

            SalaryStructure ss = new SalaryStructure(empId+2, LocalDate.now(), LocalDate.now(), base, 100, 200);
            Allowance allowance = new Allowance(empId+3, LocalDate.now(), LocalDate.now(), 5, 10, 0);
            Deduction deduction = new Deduction(empId+4, LocalDate.now(), LocalDate.now(), ss.getBasicPay()*0.05, 0, 0);

            Payroll payroll = new Payroll(emp.getEmployeeID(), LocalDate.now(), LocalDate.now(), ss, allowance, deduction);
            Payslip payslip = new Payslip(emp.getEmployeeID()+1, LocalDate.now(), LocalDate.now(), emp, payroll, period);
            payslip.generatePayslip();

        } catch (Exception e) {
            System.out.println("27335 ERROR: " + e.getMessage());
        } finally { sc.close(); }
    }
}

