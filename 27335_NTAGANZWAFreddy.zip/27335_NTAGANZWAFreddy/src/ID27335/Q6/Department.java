package ID27335.Q6;

import java.time.LocalDate;

class Department extends Organization {
    public Department(int id, LocalDate c, LocalDate u, String deptName, String deptCode, String managerName) {
        super(id, c, u, "org", deptCode, "12345678", "freddy@s.com");
    }
}
