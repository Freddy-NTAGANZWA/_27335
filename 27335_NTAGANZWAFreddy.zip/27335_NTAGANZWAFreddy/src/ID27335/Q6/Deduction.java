package ID27335.Q6;

import java.time.LocalDate;

class Deduction extends SalaryStructure {
    private double rssbContribution;
    private double payeTax;
    private double loanDeduction;

    public Deduction(int id, LocalDate c, LocalDate u, double rssbContribution, double payeTax, double loanDeduction) {
        super(id, c, u, 1, 0, 0);
        if (rssbContribution < 0 || payeTax < 0 || loanDeduction < 0) throw new IllegalArgumentException(">=0");
        this.rssbContribution = rssbContribution;
        this.payeTax = payeTax;
        this.loanDeduction = loanDeduction;
    }

    public double totalDeductions() {
        return rssbContribution + payeTax + loanDeduction;
    }
}
