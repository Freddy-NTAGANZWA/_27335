package ID27335.Q6;

import java.time.LocalDate;

final class Payslip extends Payroll {
    private int payslipNumber;
    private LocalDate issueDate;
    private Employee employee;
    private Payroll payroll;
    private PayrollPeriod period;

    public Payslip(int id, LocalDate c, LocalDate u, Employee employee, Payroll payroll, PayrollPeriod period) {
        super(id, c, u, null, null, null);
        this.payslipNumber = id;
        this.issueDate = LocalDate.now();
        this.employee = employee;
        this.payroll = payroll;
        this.period = period;
    }

    public void generatePayslip() {
        System.out.println("27335 --- PAYSLIP ---");
        System.out.println("27335 Payslip No: PS" + payslipNumber);
        System.out.println("27335 Employee: " + employee.getFullName() + " (ID: " + employee.getEmployeeID() + ")");
        System.out.println("27335 Gross Salary: " + payroll.getGross());
        System.out.println("27335 Total Deductions: " + payroll.getTotalDeductions());
        System.out.println("27335 Net Salary: " + payroll.getNet());
        System.out.println("27335 Issue Date: " + issueDate);
    }
}
