package ID27335.Q4;

import java.time.LocalDate;

class Department extends Organization {
    private String deptName;
    private String deptCode;
    private String managerName;

    public Department(int id, LocalDate c, LocalDate u, String deptName, String deptCode, String managerName) {
        super(id, c, u, "org", deptCode, "123456789", "e@x.com");
        if (deptCode == null || deptCode.length() < 3) throw new IllegalArgumentException("code>=3");
        this.deptName = deptName;
        this.deptCode = deptCode;
        this.managerName = managerName;
    }
}
