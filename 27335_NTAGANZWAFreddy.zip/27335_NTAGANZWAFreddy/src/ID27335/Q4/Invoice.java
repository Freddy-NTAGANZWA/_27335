package ID27335.Q4;

import java.time.LocalDate;

class Invoice extends Inspection {
    private String invoiceNo;
    private double invoiceAmount;

    public Invoice(int id, LocalDate c, LocalDate u, String invoiceNo, double invoiceAmount) {
        super(id, c, u, "inspector", "Passed", "OK");
        if (invoiceAmount <= 0) throw new IllegalArgumentException("amount>0");
        this.invoiceNo = invoiceNo;
        this.invoiceAmount = invoiceAmount;
    }

    public double getAmount() {
        return invoiceAmount;
    }
}
