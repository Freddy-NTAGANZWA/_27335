package ID27335.Q4;

import java.time.LocalDate;

class Product extends Supplier {
    private String productName;
    private double unitPrice;
    private int quantity;

    public Product(int id, LocalDate c, LocalDate u, String productName, double unitPrice, int quantity) {
        super(id, c, u, "sup", "123456789", "0123456789");
        if (unitPrice <= 0) throw new IllegalArgumentException("unitPrice>0");
        if (quantity < 0) throw new IllegalArgumentException("qty>=0");
        this.productName = productName;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
    }

    public double lineTotal() {
        return unitPrice * quantity;
    }
}
