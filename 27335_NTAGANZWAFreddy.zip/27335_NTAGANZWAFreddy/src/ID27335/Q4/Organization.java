package ID27335.Q4;

import java.time.LocalDate;

class Organization extends Entity {
    private String orgName;
    private String orgCode;
    private String rssbNumber;
    private String contactEmail;

    public Organization(int id, LocalDate c, LocalDate u, String orgName, String orgCode, String rssbNumber, String contactEmail) {
        super(id, c, u);
        if (rssbNumber == null || rssbNumber.length() != 8) throw new IllegalArgumentException("rssbNumber=8 digits");
        if (contactEmail == null || !contactEmail.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"))
            throw new IllegalArgumentException("invalid email");
        this.orgName = orgName;
        this.orgCode = orgCode;
        this.rssbNumber = rssbNumber;
        this.contactEmail = contactEmail;
    }
}
