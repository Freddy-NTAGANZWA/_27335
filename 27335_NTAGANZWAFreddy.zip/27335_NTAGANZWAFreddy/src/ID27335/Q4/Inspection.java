package ID27335.Q4;

import java.time.LocalDate;

class Inspection extends Delivery {
    private String inspectorName;
    private String status;
    private String remarks;

    public Inspection(int id, LocalDate c, LocalDate u, String inspectorName, String status, String remarks) {
        super(id, c, u, LocalDate.now(), "");
        if (!("Passed".equalsIgnoreCase(status) || "Failed".equalsIgnoreCase(status)))
            throw new IllegalArgumentException("status must be Passed/Failed");
        this.inspectorName = inspectorName;
        this.status = status;
        this.remarks = remarks;
    }
}
