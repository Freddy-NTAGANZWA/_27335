package ID27335.Q4;

import java.time.LocalDate;

class Supplier extends Department {
    private String supplierName;
    private String supplierTIN;
    private String contact;

    public Supplier(int id, LocalDate c, LocalDate u, String supplierName, String supplierTIN, String contact) {
        super(id, c, u, "dept", "DPT", "Manager");
        if (supplierTIN == null || !supplierTIN.matches("\\d{9}")) throw new IllegalArgumentException("TIN=9 digits");
        if (contact == null || !contact.matches("\\d{10}")) throw new IllegalArgumentException("phone 10 digits");
        this.supplierName = supplierName;
        this.supplierTIN = supplierTIN;
        this.contact = contact;
    }
}
