package ID27335.Q4;

import java.time.LocalDate;

class PurchaseOrder extends Product {
    private String poNumber;
    private LocalDate orderDate;
    private double totalAmount;

    public PurchaseOrder(int id, LocalDate c, LocalDate u, String poNumber, LocalDate orderDate, double totalAmount) {
        super(id, c, u, "prod", 1.0, 0);
        if (totalAmount <= 0) throw new IllegalArgumentException("total>0");
        this.poNumber = poNumber;
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
    }
}
