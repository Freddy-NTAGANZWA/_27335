package ID27335.Q4;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

final class ProcurementReport extends Invoice {
    private LocalDate reportDate;
    private String summary;
    private List<Invoice> invoices = new ArrayList<>();

    public ProcurementReport(int id, LocalDate c, LocalDate u, LocalDate reportDate, String summary) {
        super(id, c, u, "INV", Double.parseDouble("0"));
        this.reportDate = reportDate;
        this.summary = summary;
    }

    public void addInvoice(Invoice inv) {
        invoices.add(inv);
    }

    public void calculateTotal() {
        double total = 0;
        for (Invoice i : invoices) total += i.getAmount();
        System.out.println("27335 --- PROCUREMENT REPORT ---");
        System.out.println("27335 Report date: " + reportDate);
        System.out.println("27335 Total invoices amount: " + total);
        System.out.println("27335 Summary: " + summary);
    }
}
