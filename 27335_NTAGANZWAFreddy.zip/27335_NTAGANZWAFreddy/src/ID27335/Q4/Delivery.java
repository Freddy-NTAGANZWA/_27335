package ID27335.Q4;

import java.time.LocalDate;

class Delivery extends PurchaseOrder {
    private LocalDate deliveryDate;
    private String deliveredBy;

    public Delivery(int id, LocalDate c, LocalDate u, LocalDate deliveryDate, String deliveredBy) {
        super(id, c, u, "po", deliveryDate, 0.0);
        if (deliveryDate == null) throw new IllegalArgumentException("not null");
        this.deliveryDate = deliveryDate;
        this.deliveredBy = deliveredBy;
    }
}
