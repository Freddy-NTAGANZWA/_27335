package ID27335.Q4;

import java.time.LocalDate;
import java.util.Scanner;



public class ProcurementManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("27335 Enter organization id (>0):");
            int id = Integer.parseInt(sc.nextLine());
            System.out.println("27335 Enter organization name:");
            String orgName = sc.nextLine();
            System.out.println("27335 Enter contact email:");
            String email = sc.nextLine();
            Organization org = new Organization(id, LocalDate.now(), LocalDate.now(), orgName, "ORG", "12345678", email);

            System.out.println("27335 Enter department name:");
            String dname = sc.nextLine();
            System.out.println("27335 Enter dept code (>=3):");
            String dcode = sc.nextLine();
            Department dept = new Department(id+1, LocalDate.now(), LocalDate.now(), dname, dcode, "Manager");

            System.out.println("27335 Enter supplier name:");
            String sname = sc.nextLine();
            System.out.println("27335 Enter supplier TIN (9 digits):");
            String tin = sc.nextLine();
            System.out.println("27335 Enter supplier phone (10 digits):");
            String phone = sc.nextLine();
            Supplier supplier = new Supplier(id+2, LocalDate.now(), LocalDate.now(), sname, tin, phone);

            System.out.println("27335 Enter product name:");
            String pname = sc.nextLine();
            System.out.println("27335 Enter unit price (>0):");
            double price = Double.parseDouble(sc.nextLine());
            System.out.println("27335 Enter quantity (>=0):");
            int qty = Integer.parseInt(sc.nextLine());
            Product prod = new Product(id+3, LocalDate.now(), LocalDate.now(), pname, price, qty);

            PurchaseOrder po = new PurchaseOrder(id+4, LocalDate.now(), LocalDate.now(), "PO123", LocalDate.now(), price*qty);
            Delivery del = new Delivery(id+5, LocalDate.now(), LocalDate.now(), LocalDate.now(), "Driver A");
            Inspection insp = new Inspection(id+6, LocalDate.now(), LocalDate.now(), "Inspector", "Passed", "OK");
            Invoice inv = new Invoice(id+7, LocalDate.now(), LocalDate.now(), "INV001", price*qty);
            ProcurementReport report = new ProcurementReport(id+8, LocalDate.now(), LocalDate.now(), LocalDate.now(), "Monthly procurement");
            report.addInvoice(inv);
            report.calculateTotal();

        } catch (Exception e) {
            System.out.println("27335 ERROR: " + e.getMessage());
        } finally { sc.close(); }
    }
}

