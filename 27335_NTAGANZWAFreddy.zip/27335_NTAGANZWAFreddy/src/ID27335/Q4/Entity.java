package ID27335.Q4;

import java.time.LocalDate;

class Entity {
    private int id;
    private LocalDate createdDate;
    private LocalDate updatedDate;

    public Entity(int id, LocalDate c, LocalDate u) {
        if (id <= 0) throw new IllegalArgumentException("id>0");
    }
}
