package ID27335.Q5;

import java.time.LocalDate;

class AttendanceRecord extends ClassSession {
    private String studentID;
    private String sessionID;
    private String status;

    public AttendanceRecord(int id, LocalDate c, LocalDate u, String studentID, String sessionID, String status) {
        super(id, c, u, LocalDate.now(), "topic");
        if (!(status.equalsIgnoreCase("Present") || status.equalsIgnoreCase("Absent")))
            throw new IllegalArgumentException("status must be Present/Absent");
        this.studentID = studentID;
        this.sessionID = sessionID;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }
}
