package ID27335.Q5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class AttendanceManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("27335 Enter institution id (>0):");
            int id = Integer.parseInt(sc.nextLine());
            System.out.println("27335 Enter institution name:");
            String iname = sc.nextLine();
            Institution inst = new Institution(id, LocalDate.now(), LocalDate.now(), iname, "INST", "Address");

            System.out.println("27335 Enter department name:");
            String dname = sc.nextLine();
            Department dept = new Department(id+1, LocalDate.now(), LocalDate.now(), dname, "Head");

            System.out.println("27335 Enter course name:");
            String cname = sc.nextLine();
            System.out.println("27335 Enter course code:");
            String ccode = sc.nextLine();
            Course course = new Course(id+2, LocalDate.now(), LocalDate.now(), cname, ccode, 3);

            System.out.println("27335 Enter instructor name:");
            String iname2 = sc.nextLine();
            System.out.println("27335 Enter email:");
            String email = sc.nextLine();
            System.out.println("27335 Enter phone (10 digits):");
            String phone = sc.nextLine();
            Instructor instt = new Instructor(id+3, LocalDate.now(), LocalDate.now(), iname2, email, phone);

            List<Student> students = new ArrayList<>();
            System.out.println("27335 How many students to enter?");
            int n = Integer.parseInt(sc.nextLine());
            for (int i=0;i<n;i++){
                System.out.println("27335 Enter student name:");
                String sname = sc.nextLine();
                System.out.println("27335 Enter student ID:");
                String sid = sc.nextLine();
                System.out.println("27335 Enter age (>0):");
                int age = Integer.parseInt(sc.nextLine());
                students.add(new Student(id+10+i, LocalDate.now(), LocalDate.now(), sname, sid, age));
            }

            ClassSession session = new ClassSession(id+20, LocalDate.now(), LocalDate.now(), LocalDate.now(), "Topic A");
            AttendanceSummary summary = new AttendanceSummary(id+30, LocalDate.now(), LocalDate.now(), LocalDate.now(), 0, 0);

            for (Student s : students) {
                System.out.println("27335 Mark attendance for " + s.getStudentName() + " (P/A):");
                String st = sc.nextLine();
                AttendanceRecord rec = new AttendanceRecord(id+40, LocalDate.now(), LocalDate.now(), s.getStudentID(), session.getSessionId(), st.equalsIgnoreCase("P")?"Present":"Absent");
                summary.addRecord(rec);
            }
            summary.generateSummary(students.size(), 1); // total sessions = 1
        } catch (Exception e) {
            System.out.println("27335 ERROR: " + e.getMessage());
        } finally { sc.close(); }
    }
}

