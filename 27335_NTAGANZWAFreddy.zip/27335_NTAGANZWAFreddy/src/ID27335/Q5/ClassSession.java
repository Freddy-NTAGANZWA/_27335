package ID27335.Q5;

import java.time.LocalDate;

class ClassSession extends Student {
    private LocalDate sessionDate;
    private String topic;
    private String sessionId;

    public ClassSession(int id, LocalDate c, LocalDate u, LocalDate sessionDate, String topic) {
        super(id, c, u, "s", "SID", 1);
        if (sessionDate == null) throw new IllegalArgumentException("date not null");
        this.sessionDate = sessionDate;
        this.topic = topic;
        this.sessionId = "S" + id;
    }

    public String getSessionId() {
        return sessionId;
    }
}
