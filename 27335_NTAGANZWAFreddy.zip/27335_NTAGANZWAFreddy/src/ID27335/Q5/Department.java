package ID27335.Q5;

import java.time.LocalDate;

class Department extends Institution {
    private String departmentName;
    private String departmentHead;

    public Department(int id, LocalDate c, LocalDate u, String departmentName, String departmentHead) {
        super(id, c, u, "inst", "CODE", "addr");
        if (departmentHead == null || departmentHead.isEmpty()) throw new IllegalArgumentException("head not empty");
        this.departmentName = departmentName;
        this.departmentHead = departmentHead;
    }
}
