package ID27335.Q5;

import java.time.LocalDate;

class LeaveRequest extends AttendanceRecord {
    public LeaveRequest(int id, LocalDate c, LocalDate u, LocalDate requestDate, String reason, boolean approved) {
        super(id, c, u, "sid", "sess", "Present");
        if (reason == null || reason.isEmpty()) throw new IllegalArgumentException("reason not empty");
    }
}
