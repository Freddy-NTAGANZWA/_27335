package ID27335.Q5;

import java.time.LocalDate;

class Instructor extends Course {
    private String instructorName;
    private String email;
    private String phone;

    public Instructor(int id, LocalDate c, LocalDate u, String instructorName, String email, String phone) {
        super(id, c, u, "course", "C1", 1);
        if (email == null || !email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"))
            throw new IllegalArgumentException("invalid email");
        if (phone == null || !phone.matches("\\d{10}")) throw new IllegalArgumentException("phone 10 digits");
        this.instructorName = instructorName;
        this.email = email;
        this.phone = phone;
    }
}
