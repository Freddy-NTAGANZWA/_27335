package ID27335.Q5;

import java.time.LocalDate;

class Student extends Instructor {
    private String studentName;
    private String studentID;
    private int age;

    public Student(int id, LocalDate c, LocalDate u, String studentName, String studentID, int age) {
        super(id, c, u, "inst", "e@x", "0123456789");
        if (age <= 0) throw new IllegalArgumentException("age>0");
        this.studentName = studentName;
        this.studentID = studentID;
        this.age = age;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getStudentID() {
        return studentID;
    }
}
