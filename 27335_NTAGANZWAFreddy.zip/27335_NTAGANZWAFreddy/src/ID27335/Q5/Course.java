package ID27335.Q5;

import java.time.LocalDate;

class Course extends Department {
    private String courseName;
    private String courseCode;
    private int credits;

    public Course(int id, LocalDate c, LocalDate u, String courseName, String courseCode, int credits) {
        super(id, c, u, "dept", "Head");
        if (credits <= 0) throw new IllegalArgumentException("credits>0");
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.credits = credits;
    }
}
