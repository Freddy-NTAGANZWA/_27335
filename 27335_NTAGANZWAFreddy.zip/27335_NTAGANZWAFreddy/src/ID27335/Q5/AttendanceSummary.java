package ID27335.Q5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

final class AttendanceSummary extends LeaveRequest {
    private LocalDate reportDate;
    private int totalPresent;
    private int totalAbsent;
    private List<AttendanceRecord> records = new ArrayList<>();

    public AttendanceSummary(int id, LocalDate c, LocalDate u, LocalDate reportDate, int totalPresent, int totalAbsent) {
        super(id, c, u, reportDate, "", false);
        this.reportDate = reportDate;
        this.totalPresent = totalPresent;
        this.totalAbsent = totalAbsent;
    }

    public void addRecord(AttendanceRecord r) {
        records.add(r);
        if ("Present".equalsIgnoreCase(r.getStatus())) totalPresent++;
        else totalAbsent++;
    }

    public void generateSummary(int totalStudents, int totalSessions) {
        System.out.println("27335 --- ATTENDANCE SUMMARY ---");
        System.out.println("27335 Report Date: " + reportDate);
        System.out.println("27335 Total Present: " + totalPresent);
        System.out.println("27335 Total Absent: " + totalAbsent);
        double percent = (double) totalPresent / (totalStudents * totalSessions) * 100;
        System.out.println("27335 Attendance Percentage: " + percent + "%");
    }
}
